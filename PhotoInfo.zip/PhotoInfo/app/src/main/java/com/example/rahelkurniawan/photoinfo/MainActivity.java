package com.example.rahelkurniawan.photoinfo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    InfoDatabaseHelper userInfoDatabase;

    // Note: all button listener(except done button on EnterInfoPage.java) is added using button
    // attribute in activity_main.xml

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Call in the database
        userInfoDatabase = new InfoDatabaseHelper(this);
    }

    // Switch to enter information page
    public void enterInfoPage(View view){
        Intent enterIntent = new Intent(this, EnterInfoPage.class);
        startActivity(enterIntent);
    }

    // Switch to view information page
    public void viewPage(View view){
        Intent viewIntent = new Intent(this, InfoList.class);
        startActivity(viewIntent);
    }

    // Destroy all data if app is killed/exit (not temporary exit)
    // Temporary exit will not erase any data in database
    @Override
    protected void onDestroy(){
        super.onDestroy();
        userInfoDatabase.deleteTable();
    }

    // If exit button is pressed, finish activity
    public void exitButton(View view){
        finish();
    }

}
