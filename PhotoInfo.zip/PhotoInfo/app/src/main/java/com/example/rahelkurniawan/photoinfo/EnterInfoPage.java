package com.example.rahelkurniawan.photoinfo;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class EnterInfoPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    InfoDatabaseHelper userInfoDatabase;
    Button doneButton;
    EditText name, photographer;
    Spinner month, day, year;
    boolean insertData;

// Main -------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_info_page);

        // Done Button
        doneButton = (Button) findViewById(R.id.done_button);

        // Data Info
        name = (EditText) findViewById(R.id.name_input) ;
        photographer = (EditText) findViewById(R.id.photographer_input);
        month = (Spinner) findViewById(R.id.month);
        day = (Spinner) findViewById(R.id.day);
        year = (Spinner) findViewById(R.id.year);
        userInfoDatabase = new InfoDatabaseHelper(this);

        // Date Dropdown ------------------------------------------------------------------------
        // Note: I put all the month, day, and year options/numbers in res/values/strings.xml file

        // Month
        ArrayAdapter<CharSequence> monthAdapter = ArrayAdapter.createFromResource(
                this, R.array.month, android.R.layout.simple_spinner_item);
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        month.setAdapter(monthAdapter);
        month.setOnItemSelectedListener(this);

        // Day
        ArrayAdapter<CharSequence> dayAdapter = ArrayAdapter.createFromResource(
                this, R.array.day, android.R.layout.simple_spinner_item);
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        day.setAdapter(dayAdapter);
        day.setOnItemSelectedListener(this);

        // Year
        ArrayAdapter<CharSequence> yearAdapter = ArrayAdapter.createFromResource(
                this, R.array.year, android.R.layout.simple_spinner_item);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year.setAdapter(yearAdapter);
        year.setOnItemSelectedListener(this);

        // Add New Info to Database
        newInfo();

    }   // ----------------------------------------------------------------------------------------

// Helper -----------------------------------------------------------------------------------------

    // Save input to database when the button "DONE" is pressed and go back to main page
    public void newInfo() {
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameInput = name.getText().toString();
                String photographerInput = photographer.getText().toString();
                String monthInput = month.getSelectedItem().toString();
                String dayInput = day.getSelectedItem().toString();
                String yearInput = year.getSelectedItem().toString();

                // Extra: Check if all field is filled in
                if(nameInput.isEmpty() || photographerInput.isEmpty()){
                    insertData = false;
                }
                else{
                    // return true if all data is successfully inserted to database
                    insertData = userInfoDatabase.addData(
                            nameInput, photographerInput, monthInput, dayInput, yearInput);
                }

                // Inform users status
                if (insertData){
                    Toast.makeText(EnterInfoPage.this,
                            "Saved", Toast.LENGTH_LONG).show();
                    // Go back to previous page
                    finish();
                }
                else {
                    Toast.makeText(EnterInfoPage.this,
                            "All field must be filled in", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // Comes with the implements for listener spinner, DON'T DELETE!
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    // Comes with the implements for listener spinner, DON'T DELETE!
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // Get users information input
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        name.getText().clear();
        photographer.getText().clear();
        month.setSelection(0);
        day.setSelection(0);
        year.setSelection(0);
    }

    // Extra: Warning before pressing back button
    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(EnterInfoPage.this);
        builder.setTitle("Confirmation");
        builder.setMessage("Are you sure you want to go back?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

}
