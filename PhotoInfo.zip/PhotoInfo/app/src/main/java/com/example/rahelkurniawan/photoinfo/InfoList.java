package com.example.rahelkurniawan.photoinfo;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.SimpleCursorAdapter;

import java.util.ArrayList;

public class InfoList extends AppCompatActivity {

    InfoDatabaseHelper userInfoDatabase;
    ListView listView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_list);

        listView = findViewById(R.id.list);
        userInfoDatabase = new InfoDatabaseHelper(this);
        viewData();
    }

    private void viewData(){
        Cursor cursor = userInfoDatabase.getData();
        String name, photographer, month, day, year, date, fullInfo;

        // Array buat di ListView
        ArrayList<String> listData = new ArrayList<>();

        // looping each column in database??
        while (cursor.moveToNext()){
            // Take data from each column into string
            name = cursor.getString(1);
            photographer = cursor.getString(2);
            month = cursor.getString(3);
            day = cursor.getString(4);
            year = cursor.getString(5);

            date = "(" + month + "/" + day + "/" + year + ")";
            fullInfo = "\"" + name + "\" by " + photographer + " " + date;

            // Add data to array
            listData.add(fullInfo);
        }

        // Display data to ListView
        ListAdapter listAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, listData);
        listView.setAdapter(listAdapter);
    }

}
