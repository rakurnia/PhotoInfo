package com.example.rahelkurniawan.photoinfo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class InfoDatabaseHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "info";
    public static final String COL1 = "ID";
    public static final String COL2 = "name";
    public static final String COL3 = "photographer";
    public static final String COL4 = "month";
    public static final String COL5 = "day";
    public static final String COL6 = "year";

    // Constructor??
    public InfoDatabaseHelper(Context context) {
        super(context, TABLE_NAME, null, 1);
    }

    // Command for SQLite to create new table
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2 + " TEXT, " +
                COL3 + " TEXT, " +
                COL4 + " TEXT, " +
                COL5 + " TEXT, " +
                COL6 + " TEXT)";
        db.execSQL(createTable);
    }

    // I'm assuming...if exist a table that you want to upgrade/exchange under the same name table,
    // the existing table under that name will be deleted and will create a new one
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Put data to table
    public boolean addData(String name, String photographer, String month, String day, String year){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, name);
        contentValues.put(COL3, photographer);
        contentValues.put(COL4, month);
        contentValues.put(COL5, day);
        contentValues.put(COL6, year);

        // check if data is in or not, return in long form, not boolean
        long result = db.insert(TABLE_NAME, null, contentValues);

        // convert long to boolean
        if(result == -1) {
            return false;
        }
        else{
            return true;
        }
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);

        return cursor;
    }

    public void deleteTable(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + TABLE_NAME;
        db.execSQL(query);

    }
}
